module.exports = {
    // url : "mongodb://127.0.0.1:27017/bengkel-api"
    url : "mongodb+srv://mbing23:Wongtahulo23@cluster0.asvlpvw.mongodb.net/?retryWrites=true&w=majority"
};